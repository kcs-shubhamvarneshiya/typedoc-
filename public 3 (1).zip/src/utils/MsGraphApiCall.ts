import ApiService from "../services/ApiService";
import { ApiResponse } from "../models/ApiResponse";
import { SessionDetails } from "../models/SessionDetails";
import { msalInstance } from "../index";
import { loginRequest } from "./authConfig";

export async function handleAADLoginResponse() {
  const account = msalInstance.getActiveAccount();
  if (!account) {
    throw Error();
  }

  const response = await msalInstance.acquireTokenSilent({
    ...loginRequest,
    account: account,
  });
  
  console.log(response);
  
}

function parseJwt(token: string) {
  var base64Url = token.split(".")[1];
  var base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
  var jsonPayload = decodeURIComponent(
    window
      .atob(base64)
      .split("")
      .map(function (c) {
        return "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2);
      })
      .join("")
  );

  return JSON.parse(jsonPayload);
}
