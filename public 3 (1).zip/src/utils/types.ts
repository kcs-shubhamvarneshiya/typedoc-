export type LoaderProps = {
  isLoading: boolean;
};

export type ToastTypeProps = {
  open: number | Date;
  message: string;
  type: string;
};

export type Search = {
  ApplicationName?: string;
  search?: string;
  fromDate?: string;
  toDate?: string;
  status?: string;
  currency?: string;
  application?: string;
};

export type TransactionsType = {
  id?: string;
  transactionId?: string;
  account?: null;
  transactionDate?: null;
  applicationName?: null;
  currency?: string;
  transactionAmount?: string;
  userId?: null;
  transactionStatus?: string;
  cardType?: string;
  referenceCode?: string;
  merchant?: string;
};

type PaginationInfo = {
  pageIndex: number;
  pageSize: number;
  totalRecords: number;
};

type TransactionData = {
  paginationInfo: PaginationInfo;
  records: TransactionsType[] | RefundTransactions[];
};

export type TransactionsResponse = {
  data: TransactionData;
  errors: any;
  isSuccess: boolean;
  message: string;
};

export type RefundTransactions = Omit<
  TransactionsType,
  | "account"
  | "transactionDate"
  | "transactionAmount"
  | "transactionStatus"
  | "cardType"
> & {
  reconciliationId?: string;
  amount?: string;
  status?: string;
  refundDate?: string;
};

export type MerchantTypes = {
  label: string;
  value: string;
};

export type TransactionGraphData = {
  type: string;
  month: string;
  year: string;
  status: string;
  recordCount: string;
};

export type BarSeriesType = {
  name: string;
  data: Array<number>;
};

export type paymentTransactionDetails = {
  id: number;
  paymentInstrumentId: string;
  customerTokenId: string;
  cardLast4Digits: string;
  referenceInformationCode: string;
  isCapture: boolean;
  totalAmount: number;
  currency: string;
  merchantRef: string;
  ignoreAvsResult: string;
  declineAvsCodes: string;
  applicationName: string;
  paymentCaptureId: string;
  terminalId: string;
  processorApprovalCode: string;
  networkTransactionId: string;
  processorResponseCode: string;
  processorTransactionId: string;
  avsCode: string;
  avsCodeRaw: string;
  errorReason: string;
  errorMessage: string;
  responseInsightsCategory: string;
  responseInsightsCategoryCode: string;
  reconciliationId: string;
  paymentCaptureStatus: string;
  paymentSubmitTime: string;
  cardType: string;
  userId: string;
  account: string;
};

export type refundPaymentTransactionDetails = paymentTransactionDetails & {
  refundAmount?: number;
  refundCurrency?: string;
  refundStatus?: string;
  requestedAmount?: number;
  refundSubmitTime?: string;
  transactionId?: string;
  errorDetail?: string;
};
export type billTo = {
  firstName: string;
  lastName: string;
  company: string;
  address1: string;
  locality: string;
  postalCode: string;
  country: string;
  email: string;
  administrativeArea: string;
  phoneNumber: string;
};

export type card = {
  number: string;
  expirationMonth: number;
  expirationYear: number;
  type: string;
  cardState: string;
};
export type customerDetails = {
  id: string;
  instrumentObject: string;
  state: string;
  accountNumber: string;
  card: card;
  billTo: billTo;
  creator: string;
};

export type TransactionMaster = {
  paymentTransactionDetails: paymentTransactionDetails;
  customerDetails: customerDetails;
};

export type RefundedTransactionMaster = {
  refundPaymentTransactionDetails: refundPaymentTransactionDetails;
  customerDetails: customerDetails;
};

export type Transaction = {
  data: TransactionMaster;
  errors: any;
  isSuccess: boolean;
  message: string;
};

export type RefundTransaction = Transaction & {
  data: RefundedTransactionMaster;
};

export type SecurityKey = {
  id: number;
  application: string;
  publicKey?: string;
  remarks?: string;
  createdBy?: string;
  createdOn?: string;
  updatedOn?: string;
  updatedBy?: string;
  isActive?: boolean;
};

export type SecurityKeyBody = {
  application: number;
  remarks: string;
};

export type SecurityKeyResponse = {
  data: SecurityKey[];
  errors: any;
  isSuccess: boolean;
  message: string;
};

export enum ApplicationType {
  CCDB = 1,
  JDE,
}

export enum UserRole {
  ADMIN = 1,
  USER,
}
