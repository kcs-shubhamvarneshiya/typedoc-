export type HTSMaterialDetail = {
    id:number
    description: string
    isActive: boolean
    updatedBy?:number
    updatedDate?: Date
}