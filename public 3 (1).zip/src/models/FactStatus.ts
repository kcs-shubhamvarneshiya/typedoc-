export type FactStatus = {
    id: number;
    Description: string;
    isActive: boolean;
    UpdatedBy: number;
    UpdatedDate: Date;
}