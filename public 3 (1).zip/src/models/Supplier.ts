export type Supplier = {
    id: number;
    Name: string;
    isActive: boolean;
    UpdatedBy: number;
    UpdatedDate: Date;
}