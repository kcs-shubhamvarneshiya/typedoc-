export type PrjStatus = {
    id: number;
    Description: string;
    Sort: number;
    Activity:number;
    isActive: boolean;
    UpdatedBy: number;
    UpdatedDate: Date;
}