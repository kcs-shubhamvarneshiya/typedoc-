export type AttachmentType = {
    id: number;
    Name: string;
    AttachType: string;
    Family: string;
    Item: string;
    Prefix: string
    Lvl: string;
    isActive: boolean;
    UpdatedBy: number;
    UpdatedDate: Date;
}