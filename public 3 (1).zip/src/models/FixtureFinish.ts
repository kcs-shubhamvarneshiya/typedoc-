export type FixtureFinish = {
    id: number;
    FinishCode:string;
    FinishName:string;
    isActive: boolean;
    UpdatedBy: number;
    UpdatedDate: Date;
}