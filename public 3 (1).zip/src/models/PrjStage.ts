export type PrjStage = {
    id: number;
    Description: string;
    Family: string;
    Item: string;
    Activity:number;
    isActive: boolean;
    UpdatedBy: number;
    UpdatedDate: Date;
}