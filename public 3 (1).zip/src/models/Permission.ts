export type Permission = {
  id: number;
  name: string;
};
