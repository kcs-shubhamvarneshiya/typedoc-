export type Category = {
    id: number;
    description: string;
    sort: number;
    isActive: boolean;
    updatedBy?: number;
    updatedDate?: Date;
}