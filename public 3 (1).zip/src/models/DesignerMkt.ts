export type DesignerMkt = {
    id: number;
    Designer: string;
    Prefix: string;
    isActive: boolean;
    UpdatedBy: number;
    UpdatedDate: Date;
}