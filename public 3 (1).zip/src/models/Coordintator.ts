export type Coordinator = {
    id: number;
    Name: string;
    isActive: boolean;
    UpdatedBy: number;
    UpdatedDate: Date;
}