export type ApiResponse<T> = {
    [x: string]: any;
    isSuccess: boolean;
    message: string;
    data: T;    
}