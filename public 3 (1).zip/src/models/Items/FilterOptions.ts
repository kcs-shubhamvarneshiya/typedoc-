export type ProductFilterOptions = {
  stockCodes?: string[];
  baseCodes?: string[];
  pdCodes?: string[];
  familyNames?: string[];
  pdFamilyNames?: string[];
  projectStages?: KeyValues[];
  projectStatuses?: KeyValues[];
  productFactoryStatuses?: KeyValues[];
  productcategories?: KeyValues[];
  productFunctions?: KeyValues[];
  productSuppliers?: KeyValues[];
  productPriorities?: number[];
  productDesignerMkts?: KeyValues[];
  productDesignerRyts?: KeyValues[];
  productIntroDatess?: Date[];
  fixtureFinishes?: KeyValuesWithCode[];
  brands?: KeyValues[];
  primaryMaterials?: KeyValuesWithCode[];
  secondaryMaterials?: KeyValuesWithCode[];
  style?: KeyValues[];
  coordinator?: KeyValues[];
  skuType?: KeyValues[];
  sLType?: KeyValues[];
  attachment?: KeyValuesWithCode[];
  projectCode?: string;
};

export type PickListFilterResponse = {
  data: [];
  isSuccess: boolean;
  message: string;
};

type KeyValues = {
  id: number;
  name: string;
  description: string;
};

type KeyValuesWithCode = {
  id: number;
  name: string;
  code: string;
  attachType: string;
  description: string;
};
