export type DesignerRyt = {
    id: number;
    Designer: string;
    isActive: boolean;
    UpdatedBy: number;
    UpdatedDate: Date;
}