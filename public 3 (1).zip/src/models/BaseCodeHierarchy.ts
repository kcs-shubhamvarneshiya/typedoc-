export type BaseCodeHierarchy = {
    id: number
    rank: number
    attachType: string
    isActive: boolean
    updatedBy?: number
    updatedDate?: Date 
}