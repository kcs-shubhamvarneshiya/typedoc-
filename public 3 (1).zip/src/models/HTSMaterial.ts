export type HTSMaterial = {
    id: number 
    description: string
    isActive: boolean
    updatedBy: number 
    updatedDate: Date;
}