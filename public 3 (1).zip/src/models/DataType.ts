export type DataType = {
    id:number
    description: string
}