import { Snackbar, Alert, AlertColor } from "@mui/material";
import Stack from "@mui/material/Stack";
import { useEffect, useState } from "react";
import { ToastTypeProps } from "../utils/types";

export default function Toast(props: ToastTypeProps) {
  let { open, message, type } = props;
  const [openToast, setOpenToast] = useState(Boolean);

  const handleClose = (
    event?: React.SyntheticEvent | Event,
    reason?: string
  ) => {
    if (reason === "clickaway") {
      return;
    }
    setOpenToast(false);
  };
  useEffect(() => {
    if (open !== 0 && message !== "") setOpenToast(true);
  }, [open, message]);
  return (
    <Stack spacing={2} sx={{ width: "100%" }}>
      <Snackbar
        open={openToast}
        onClose={handleClose}
        autoHideDuration={7000}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
      >
        <Alert
          onClose={() => setOpenToast(false)}
          severity={type as AlertColor}
          sx={{ width: "100%" }}
        >
          {message}
        </Alert>
      </Snackbar>
    </Stack>
  );
}
